package DefineClassPerson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;

public class Main {
    public static void main(String[] args) throws IOException {


            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            Class person = Person.class;

            Field[] fields = person.getDeclaredFields();
            System.out.println(fields.length);


            br.close();


    }
}
